/* CTA experiment v1. Local diagnostic counts only; dataLayer events are integration-ready. */
(()=>{'use strict';
const key='waqas-cta-v1',forced=new URLSearchParams(location.search).get('variant');
const preview=forced==='a'||forced==='b';let variant;
try{variant=localStorage.getItem(key);if(!['a','b'].includes(variant)){variant=Math.random()<.5?'a':'b';localStorage.setItem(key,variant);}}catch{variant=Math.random()<.5?'a':'b';}
if(preview)variant=forced;
let exposed=false,clicked=false;try{exposed=sessionStorage.getItem(key+'-exposed')===variant;clicked=sessionStorage.getItem(key+'-clicked')===variant;}catch{}
function event(name,props={}){
 if(preview)return;
 const payload={event:name,experiment:'hero_cta_v1',variant,...props};
 window.dataLayer=window.dataLayer||[];window.dataLayer.push(payload);
 window.dispatchEvent(new CustomEvent('portfolio_event',{detail:payload}));
 try{const counts=JSON.parse(localStorage.getItem(key+'-counts')||'{}');const k=variant+':'+name;counts[k]=(counts[k]||0)+1;localStorage.setItem(key+'-counts',JSON.stringify(counts));}catch{}
}
function exposure(){if(exposed)return;exposed=true;try{sessionStorage.setItem(key+'-exposed',variant);}catch{}event('cta_exposure',{placement:'hero'});}
const hero=document.querySelector('[data-enquiry="hero"]'),label=document.querySelector('[data-cta-label]');
if(label)label.textContent=variant==='a'?'Discuss your project':'Get a project estimate';
if(hero){if('IntersectionObserver'in window){const obs=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){exposure();obs.disconnect();}},{threshold:.5});obs.observe(hero);}else exposure();
hero.addEventListener('click',()=>{exposure();if(!clicked){clicked=true;try{sessionStorage.setItem(key+'-clicked',variant);}catch{}event('cta_click',{placement:'hero'});}});}
document.querySelectorAll('a[href^="mailto:"],a[href^="tel:"],a[href*="wa.me/"]').forEach(a=>a.addEventListener('click',()=>event('contact_intent',{channel:a.href.startsWith('mailto:')?'email':a.href.startsWith('tel:')?'phone':'whatsapp'})));
document.querySelector('#project-brief')?.addEventListener('submit',e=>{e.preventDefault();const type=document.querySelector('#brief-type').value,brief=document.querySelector('#brief-message').value.trim();if(!brief)return;event('enquiry_draft',{project_type:type});location.href='mailto:muhammadwaqasidrees590@gmail.com?subject='+encodeURIComponent(type+' enquiry')+'&body='+encodeURIComponent('Project type: '+type+'\n\n'+brief);});
window.portfolioMetrics={variant,preview,report(){try{return {scope:'This browser only — not aggregate visitor results',experiment:'hero_cta_v1',counts:JSON.parse(localStorage.getItem(key+'-counts')||'{}')};}catch{return {scope:'Local storage unavailable'};}},reset(){try{localStorage.removeItem(key+'-counts');sessionStorage.removeItem(key+'-clicked');sessionStorage.removeItem(key+'-exposed');}catch{}}};
})();
